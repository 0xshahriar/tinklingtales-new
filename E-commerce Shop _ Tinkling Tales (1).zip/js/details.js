// Product Details Page Functionality
document.addEventListener('DOMContentLoaded', function() {
    // Product Image Gallery
    const mainImage = document.getElementById('main-product-image');
    const thumbnails = document.querySelectorAll('.product-thumbnail');
    
    thumbnails.forEach(thumbnail => {
        thumbnail.addEventListener('click', function() {
            const imageUrl = this.getAttribute('data-image');
            
            // Update main image
            mainImage.src = imageUrl;
            
            // Update active thumbnail
            thumbnails.forEach(thumb => thumb.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // Size Selection
    const sizeOptions = document.querySelectorAll('.size-option');
    sizeOptions.forEach(option => {
        option.addEventListener('click', function() {
            sizeOptions.forEach(opt => opt.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // Quantity Selector
    const quantityInput = document.querySelector('.quantity-input');
    const minusBtn = document.querySelector('.quantity-btn.minus');
    const plusBtn = document.querySelector('.quantity-btn.plus');
    
    if (minusBtn && plusBtn && quantityInput) {
        minusBtn.addEventListener('click', function() {
            let currentValue = parseInt(quantityInput.value);
            if (currentValue > 1) {
                quantityInput.value = currentValue - 1;
            }
        });
        
        plusBtn.addEventListener('click', function() {
            let currentValue = parseInt(quantityInput.value);
            if (currentValue < 10) {
                quantityInput.value = currentValue + 1;
            }
        });
        
        quantityInput.addEventListener('change', function() {
            let value = parseInt(this.value);
            if (isNaN(value) || value < 1) {
                this.value = 1;
            } else if (value > 10) {
                this.value = 10;
            }
        });
    }

    // Add to Cart
    const addToCartBtn = document.querySelector('.add-to-cart');
    if (addToCartBtn) {
        addToCartBtn.addEventListener('click', function() {
            const product = {
                id: 1,
                name: document.querySelector('.product-title').textContent,
                price: 29.99,
                quantity: parseInt(quantityInput.value),
                size: document.querySelector('.size-option.active').textContent,
                image: 'assets/images/demo.png'
            };
            
            addToCart(product.id, product.name, product.price, product.quantity);
            
            // Show success message
            const originalText = this.innerHTML;
            this.innerHTML = '<i class="bx bx-check"></i> Added to Cart!';
            this.style.background = '#2ed573';
            
            setTimeout(() => {
                this.innerHTML = originalText;
                this.style.background = '';
            }, 2000);
        });
    }

    // Add to Wishlist
    const addToWishlistBtn = document.querySelector('.add-to-wishlist');
    if (addToWishlistBtn) {
        addToWishlistBtn.addEventListener('click', function() {
            const originalText = this.innerHTML;
            this.innerHTML = '<i class="bx bx-heart"></i> Added to Wishlist!';
            this.style.borderColor = '#ff4757';
            this.style.color = '#ff4757';
            
            setTimeout(() => {
                this.innerHTML = originalText;
                this.style.borderColor = '';
                this.style.color = '';
            }, 2000);
        });
    }

    // Product Tabs
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabPanels = document.querySelectorAll('.tab-panel');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetTab = this.getAttribute('data-tab');
            
            // Update active tab button
            tabButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Show target tab panel
            tabPanels.forEach(panel => {
                panel.classList.remove('active');
                if (panel.id === targetTab) {
                    panel.classList.add('active');
                }
            });
        });
    });

    // Share buttons
    const shareButtons = document.querySelectorAll('.share-button');
    shareButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const platform = this.querySelector('i').className.split('-')[1];
            alert(`Sharing via ${platform} will be implemented soon!`);
        });
    });

    // Related products click
    const relatedProducts = document.querySelectorAll('.related-product .button');
    relatedProducts.forEach(button => {
        button.addEventListener('click', function() {
            // In a real implementation, this would navigate to the product details
            alert('Product details page would open here.');
        });
    });
});

// Enhanced add to cart function for product details
function addToCart(id, name, price, quantity = 1) {
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    const existingItem = cartItems.find(item => item.id === id);
    
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        cartItems.push({ 
            id, 
            name, 
            price, 
            quantity,
            image: 'assets/images/demo.png'
        });
    }
    
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    updateCartUI();
}