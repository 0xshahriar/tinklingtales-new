// Registration Page Functionality
document.addEventListener('DOMContentLoaded', function() {
    const registrationForm = document.getElementById('registration-form');
    const passwordInput = document.getElementById('reg-password');
    const confirmPasswordInput = document.getElementById('reg-confirm-password');
    const passwordStrengthBar = document.querySelector('.password-strength-bar');
    const passwordStrengthText = document.querySelector('.password-strength-text');

    // Password strength indicator
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            let strength = 0;
            let text = 'Weak';
            let color = '#ff4757';

            // Check password strength
            if (password.length >= 8) strength++;
            if (password.match(/[a-z]+/)) strength++;
            if (password.match(/[A-Z]+/)) strength++;
            if (password.match(/[0-9]+/)) strength++;
            if (password.match(/[!@#$%^&*(),.?":{}|<>]+/)) strength++;

            // Update strength indicator
            switch(strength) {
                case 0:
                case 1:
                    text = 'Weak';
                    color = '#ff4757';
                    break;
                case 2:
                case 3:
                    text = 'Medium';
                    color = '#ffa502';
                    break;
                case 4:
                    text = 'Strong';
                    color = '#2ed573';
                    break;
                case 5:
                    text = 'Very Strong';
                    color = '#1e90ff';
                    break;
            }

            if (passwordStrengthBar) {
                passwordStrengthBar.style.width = (strength * 20) + '%';
                passwordStrengthBar.style.backgroundColor = color;
            }
            
            if (passwordStrengthText) {
                passwordStrengthText.textContent = text;
                passwordStrengthText.style.color = color;
            }
        });
    }

    // Password confirmation validation
    if (confirmPasswordInput && passwordInput) {
        confirmPasswordInput.addEventListener('input', function() {
            if (this.value !== passwordInput.value) {
                this.style.borderColor = '#ff4757';
            } else {
                this.style.borderColor = '#2ed573';
            }
        });
    }

    // Form submission
    if (registrationForm) {
        registrationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);
            
            // Validation
            if (!data.firstName || !data.lastName || !data.email || !data.password) {
                alert('Please fill in all required fields.');
                return;
            }

            if (data.password !== data.confirmPassword) {
                alert('Passwords do not match.');
                return;
            }

            if (!data.terms) {
                alert('Please accept the Terms of Service and Privacy Policy.');
                return;
            }

            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(data.email)) {
                alert('Please enter a valid email address.');
                return;
            }

            // Password strength validation
            if (passwordInput.value.length < 8) {
                alert('Password must be at least 8 characters long.');
                return;
            }

            // Simulate registration
            const submitButton = this.querySelector('button[type="submit"]');
            const originalText = submitButton.textContent;
            
            submitButton.innerHTML = '<div class="loading"></div> Creating Account...';
            submitButton.disabled = true;

            setTimeout(() => {
                alert('Account created successfully! Welcome to Tinkling Tales.');
                registrationForm.reset();
                submitButton.textContent = originalText;
                submitButton.disabled = false;
                
                // Redirect to login page
                window.location.href = 'login.html';
            }, 2000);
        });
    }

    // Social registration buttons
    const socialButtons = document.querySelectorAll('.social-button');
    socialButtons.forEach(button => {
        button.addEventListener('click', function() {
            const platform = this.textContent.trim();
            alert(`${platform} registration will be implemented soon!`);
        });
    });
});