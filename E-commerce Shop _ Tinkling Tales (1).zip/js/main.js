// main.js - Enhanced with error handling and bangles store functionality

//Swiper JS Home - Only initialize if element exists
if (document.querySelector(".home-swiper")) {
    var homeSwiper = new Swiper(".home-swiper", {
        spaceBetween: 30,
        loop: true,
        autoplay: {
            delay: 5000,
            disableOnInteraction: false,
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
    });
}

// Scroll Header
function scrollHeader(){
    const header = document.getElementById('header');
    if(this.scrollY >= 10) header.classList.add('scroll-header'); 
    else header.classList.remove('scroll-header');
}
window.addEventListener('scroll', scrollHeader);

//Swiper JS New - Only initialize if element exists
if (document.querySelector(".new-swiper")) {
    var newSwiper = new Swiper(".new-swiper", {
        spaceBetween: 16,
        centeredSlides: true,
        slidesPerView: 1,
        loop: true,
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
        breakpoints: {
            576: {
                slidesPerView: 2,
            },
            776: {
                slidesPerView: 3,
            },
            992: {
                slidesPerView: 4,
            }
        }
    });
}

// Testimonials Swiper - Only initialize if element exists
if (document.querySelector(".testimonials-swiper")) {
    var testimonialsSwiper = new Swiper(".testimonials-swiper", {
        spaceBetween: 30,
        loop: true,
        autoplay: {
            delay: 4000,
            disableOnInteraction: false,
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        breakpoints: {
            576: {
                slidesPerView: 2,
            }
        }
    });
}

// Show Cart 
const cart = document.getElementById('cart');
const cartShop = document.getElementById('cart-shop');
const cartClose = document.getElementById('cart-close');

if(cartShop && cart) { 
    cartShop.addEventListener("click", () => { 
        cart.classList.add('show-cart'); 
        updateCartUI();
    }); 
}

if(cartClose && cart) { 
    cartClose.addEventListener("click", () => { 
        cart.classList.remove('show-cart'); 
    }); 
}

// Show Login
const login = document.getElementById('login');
const loginButton = document.getElementById('login-button');
const loginClose = document.getElementById('login-close');

if(loginButton && login) { 
    loginButton.addEventListener("click", () => { 
        login.classList.add('show-login'); 
    });
}

if(loginClose && login) { 
    loginClose.addEventListener("click", () => { 
        login.classList.remove('show-login'); 
    }); 
}

// Show Scroll up 
function scrollUp(){
    const scrollUp = document.getElementById('scroll-up');
    if(this.scrollY >= 350) scrollUp.classList.add('show-scroll'); 
    else scrollUp.classList.remove('show-scroll');
}
window.addEventListener("scroll", scrollUp);

// Enhanced Menu Toggle with Z-Index Management
const navMenu = document.getElementById('nav-menu');
const navToggle = document.getElementById('nav-toggle');
const navClose = document.getElementById('nav-close');

if(navToggle && navMenu) { 
    navToggle.addEventListener("click", () => { 
        navMenu.classList.add('show-menu');
        // Disable body scroll when menu is open
        document.body.style.overflow = 'hidden';
    });
}

if(navClose && navMenu) { 
    navClose.addEventListener("click", () => { 
        navMenu.classList.remove('show-menu');
        // Re-enable body scroll when menu is closed
        document.body.style.overflow = '';
    }); 
}

// Close menu when clicking on a link
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
        if (navMenu) {
            navMenu.classList.remove('show-menu');
            document.body.style.overflow = '';
        }
    });
});

// Close menu when clicking outside (on overlay)
if (navMenu) {
    navMenu.addEventListener('click', (e) => {
        if (e.target === navMenu) {
            navMenu.classList.remove('show-menu');
            document.body.style.overflow = '';
        }
    });
}

// Close menus when clicking outside
document.addEventListener('click', (e) => {
    if (cart && !cart.contains(e.target) && cartShop && !cartShop.contains(e.target) && cart.classList.contains('show-cart')) {
        cart.classList.remove('show-cart');
    }
    if (login && !login.contains(e.target) && loginButton && !loginButton.contains(e.target) && login.classList.contains('show-login')) {
        login.classList.remove('show-login');
    }
});

// Newsletter form submission
const newsletterForm = document.getElementById('newsletter-form');
if (newsletterForm) {
    newsletterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = this.querySelector('input[type="email"]').value;
        // Here you would typically send to your backend
        alert('Thank you for subscribing with: ' + email);
        this.reset();
    });
}

// Login form submission
const loginForm = document.getElementById('login-form');
if (loginForm) {
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        
        // Simple validation
        if (email && password) {
            // Here you would typically authenticate with backend
            alert('Login successful!');
            if (login) login.classList.remove('show-login');
            loginForm.reset();
        } else {
            alert('Please fill in all fields');
        }
    });
}

// Initialize cart functionality
function updateCartUI() {
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    const cartContainer = document.getElementById('cart-container');
    const cartCount = document.getElementById('cart-count');
    const cartTotal = document.getElementById('cart-total');
    
    if (cartContainer) {
        if (cartItems.length === 0) {
            cartContainer.innerHTML = '<div class="cart-empty" id="cart-empty"><i class="bx bx-cart"></i><p>Your cart is empty</p></div>';
            if (cartCount) cartCount.textContent = '0 items';
            if (cartTotal) cartTotal.textContent = '$0';
        } else {
            // Update cart items display
            let total = 0;
            cartContainer.innerHTML = cartItems.map(item => {
                total += item.price * item.quantity;
                return `
                    <article class="cart-card">
                        <div class="cart-box">
                            <img src="assets/images/demo.png" alt="${item.name}" class="cart-img">
                        </div>
                        <div class="cart-details">
                            <h3 class="cart-title">${item.name}</h3>
                            <span class="cart-price">$${item.price}</span>
                            <div class="cart-amount">
                                <div class="cart-amount-content">
                                    <span class="cart-amount-box" onclick="updateQuantity(${item.id}, -1)"><i class="bx bx-minus"></i></span>
                                    <span class="cart-amount-number">${item.quantity}</span>
                                    <span class="cart-amount-box" onclick="updateQuantity(${item.id}, 1)"><i class="bx bx-plus"></i></span>
                                </div>
                                <i class="bx bx-trash-alt cart-amount-trash" onclick="removeFromCart(${item.id})"></i>
                            </div>
                        </div>
                    </article>
                `;
            }).join('');
            
            if (cartCount) cartCount.textContent = `${cartItems.reduce((sum, item) => sum + item.quantity, 0)} items`;
            if (cartTotal) cartTotal.textContent = `$${total.toFixed(2)}`;
        }
    }
}

// Clear cart functionality
const clearCartBtn = document.getElementById('clear-cart');
if (clearCartBtn) {
    clearCartBtn.addEventListener('click', () => {
        if (confirm('Are you sure you want to clear your cart?')) {
            localStorage.removeItem('cartItems');
            updateCartUI();
        }
    });
}

// Load new arrival products
function loadNewArrivals() {
    const newProductsContainer = document.getElementById('new-products');
    if (newProductsContainer) {
        // This would typically come from an API
        const products = [
            { id: 1, name: "Gold Plated Bangles", price: 14.99, oldPrice: 29.99, category: "Traditional Collection" },
            { id: 2, name: "Silver Designer Bangles", price: 11.99, oldPrice: 21.99, category: "Contemporary Style" },
            { id: 3, name: "Bridal Set Bangles", price: 24.99, oldPrice: 44.99, category: "Wedding Collection" },
            { id: 4, name: "Oxidized Silver Bangles", price: 16.99, oldPrice: 32.99, category: "Antique Collection" }
        ];

        newProductsContainer.innerHTML = products.map(product => `
            <div class="new-content swiper-slide">
                <div class="new-tag">New</div>
                <img src="assets/images/demo.png" alt="${product.name}" class="new-img">
                <h3 class="new-title">${product.name}</h3>
                <span class="new-subtitle">${product.category}</span>
                <div class="new-prices">
                    <span class="new-price">$${product.price}</span>
                    <span class="new-discount">$${product.oldPrice}</span>
                </div>
                <button class="button new-button" onclick="addToCart(${product.id}, '${product.name}', ${product.price})">
                    <i class="bx bx-cart-alt new-icon"></i>
                </button>
            </div>
        `).join('');
    }
}

// Global functions for cart operations
function addToCart(id, name, price) {
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    const existingItem = cartItems.find(item => item.id === id);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cartItems.push({ id, name, price, quantity: 1 });
    }
    
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    updateCartUI();
    alert('Item added to cart!');
}

function updateQuantity(id, change) {
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    const item = cartItems.find(item => item.id === id);
    
    if (item) {
        item.quantity += change;
        if (item.quantity <= 0) {
            cartItems = cartItems.filter(item => item.id !== id);
        }
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
        updateCartUI();
    }
}

function removeFromCart(id) {
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    cartItems = cartItems.filter(item => item.id !== id);
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    updateCartUI();
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    updateCartUI();
    loadNewArrivals();
    scrollHeader(); // Initialize scroll header
    
    // Add smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
});